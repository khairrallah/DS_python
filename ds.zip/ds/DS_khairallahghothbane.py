# -*- coding: utf-8 -*-
"""
Created on Sat Nov  1 15:44:14 2023

@author: khair
"""
from hashlib import sha256
import sys
import re

def valider_email(email):
    # Expression régulière pour valider l'adresse e-mail
    pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(pattern, email)

def valider_mot_de_passe(pwd):
    # Expression régulière pour valider le mot de passe
    pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
    return re.match(pattern, pwd)

def affichermenucesar():
    print("Menu :")
    print("1.  chifrer le message  ")
    print("2.  dechifrer le message ")
    
def affichermenuAuth():
    print("Menu :")
    print("1.  Donnez un mot à haché ")
    print("2.  Décalage par CESAR ")
    print("3.  Collecter une Dataset de votre choix ")
    print("4. retour aux menu ")

def afficher_menu():
    print("Menu :")
    print("1. registrer")
    print("2. authentifier")
    
    print("4. Quitter")
    
def recupermail():
    email= input(" veuillez saisir votre E-mail ")
    return email

def recuperpass():
 pwd= input("Veuillez saisir votre mot de passe ")   
 return pwd

def option1():
    
    email = recupermail()
    if valider_email(email):
        pwd = recuperpass()
        if valider_mot_de_passe(pwd):
           with open('tst.txt', 'a') as fichier:
               fichier.write(f'Email: {email}, Pwd: {pwd}\n') 
               print("Enregistrement réussi!")
        else:
            print("Le mot de passe ne respecte pas les critères.")
    else:
        print("L'adresse e-mail n'est pas valide.")

   

    

def option2():
    options = {
        '1': mothache,
        '2': decl_cesar,
        '3': collect_dataset,
        '4': quitter
    }
    print("pour vous authentifier veuillez saisir vos coordonnees (:*)")
    email = input("Veuillez saisir votre adresse e-mail: ")
    mot_de_passe = input("Veuillez saisir votre mot de passe: ")
    with open('tst.txt', 'r') as fichier:
        lignes = fichier.readlines()
        found = False 
    for ligne in lignes:
        
        if f'Email: {email}, Pwd: {mot_de_passe}' in ligne:
            found = True
            print(f'bonjour {email}')
            affichermenuAuth()
            choix = input("Veuillez choisir une option (1/2/3/4) : ")
            if choix in options:
                options[choix]()  
            else:
                print("Option invalide. Veuillez choisir une option valide.")
                break
        
    if not found:
         print('vos coordonnees ne sont pas enregistrees veuillez vous enregistrer')  



def quitter():
    print("Au revoir !")
    sys.exit()
    
def attaque_par_dictionnaire():
	
    from hashlib import sha256
    from datetime import datetime    
    
    pwd=recupermot()
    dic=open('dic.txt', mode='r')
    n=0
    t=datetime.now()
    for mot in dic:
        mot=mot.strip()
        n += 1
        if sha256(mot.encode()).hexdigest()==pwd :
           print ("Mot de passe trouvé", mot, "pensez à le changer")
           print (n, "mots testés en " (datetime.now()-t).total_seconds(), " secondes")
           dic.close()
		
    print ()
    print ("Mot de passe non trouvé, aucun haché ne correspond à votre haché", pwd)
    
def recupermot():
    mot= input(" donner un mot a haché ")
    return mot   
    
def mothache():
    from hashlib import sha256
    choix=input("1- haché le mot donnée \n 2- attacker le mot donner par dicitionaire ")
    mot= recupermot()
    if choix=='1':
      
      print( sha256(mot.encode()).hexdigest())
    elif choix=='2':
      attaque_par_dictionnaire() 
        
    affichermenuAuth()
    option2()
    
def chifrer26lettre () :
    motc = input('donner un mot a chifrer')
    decalage = 3
    mot_chiffre = ""
    for lettre in motc:
        if lettre.isalpha():
            ascii_val = ord(lettre)
            if lettre.isupper():
                ascii_val = ((ascii_val - ord('A') + decalage) % 26) + ord('A')
            elif lettre.islower():
                ascii_val = ((ascii_val - ord('a') + decalage) % 26) + ord('a')
            lettre_chiffree = chr(ascii_val)
            mot_chiffre += lettre_chiffree
        else:
            mot_chiffre += lettre
    
    print(f'Mot original : {motc}')
    print(f'Mot chiffré : {mot_chiffre}') 
    
def chifrercesarascci () :
    motc = input('donner un mot a chifrer')
    decalage = 3
    mot_chiffre = ""
    for lettre in motc:
        ascii_val = ord(lettre)
        ascii_val = (ascii_val + decalage) % 128  # Utilisation de 128 pour couvrir tous les caractères ASCII
        caractere_chiffre = chr(ascii_val)
        mot_chiffre += caractere_chiffre
    
    print(f'Mot original : {motc}')
    print(f'Mot chiffré : {mot_chiffre}')
def dechifrercesarascci () :
    motc = input('donner un mot a dechifrer')
    decalage = 3
    mot_dechiffre = ""
    for lettre in motc:
        
            ascii_val = ord(lettre)
            ascii_val = (ascii_val - decalage) % 128  # Utilisation de 128 pour couvrir tous les caractères ASCII
            caractere_dechiffre = chr(ascii_val)
            mot_dechiffre += caractere_dechiffre
    
    print(f'Mot original : {motc}')
    print(f'Mot chiffré : {mot_dechiffre}')    

def decl_cesar():
    affichermenucesar()
    
    choix=input("1- pour utiliser Cesar avec code ASCII /n 2- pour utiliser cesar 26 lettres  \n 3- dechifrerer un message ")
    if choix == '1' :
        chifrer26lettre()
        
      
    elif  choix=='2':
        chifrercesarascci ()
        
    elif  choix=='3':
        dechifrercesarascci()
        
     
    
    affichermenuAuth()
    option2()
        
def collect_dataset():
    import pandas as pd
    import matplotlib.pyplot as plt

    # Collecte de données (ex. fictives pour l'exemple)
    data = {'x': [25, 30, 35, 40],
            'y': [85, 92, 78, 88]}

    # Affichage du Dataset sous forme de dictionnaire
    print("Dataset sous forme de dictionnaire:")
    print(data)

    # Conversion en DataFrame (pour une manipulation plus facile)
    df = pd.DataFrame(data)

    # Affichage des premières lignes du DataFrame
    print("\nDataFrame:")
    print(df)

    # Affichage des courbes (ex. âge vs. score)
    plt.figure(figsize=(15, 10))
    plt.plot(df['x'], df['y'], marker='o')
    plt.title('x y')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.show()
    affichermenuAuth()
    option2()
    

# Création d'un dictionnaire associant les options aux fonctions correspondantes
options = {
    '1': option1,
    '2': option2,
    
    '3': quitter
}

# Boucle principale du menu
while True:
    afficher_menu()

    choix = input("Veuillez choisir une option (1/2/3/4) : ")

    # Vérification si le choix de l'utilisateur est une option valide
    if choix in options:
        options[choix]()
   
    else:
        print("Option invalide. Veuillez choisir une option valide.")
